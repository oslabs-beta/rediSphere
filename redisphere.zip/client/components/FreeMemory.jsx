import React from 'react';

const FreeMemory = () => {
  return (
    <>
      <p>Free memory</p>
      <h3>29MB</h3>
    </>
  );
};

export default FreeMemory;
